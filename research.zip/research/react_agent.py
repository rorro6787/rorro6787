from langgraph.graph import StateGraph, END
from langgraph.graph import StateGraph
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage
from langchain_core.messages import ToolMessage, SystemMessage
import json
from src.utils.template_config import apply_prompt_template




from langgraph.graph import StateGraph, END

class ReactAgent():
    def __init__(self, model, tools, prompt, name, state_class: type):
        self.model = model
        self.tools = tools
        self.prompt = prompt
        self.name = name
        self.state_class = state_class
        self.tools_by_name = {tool.name: tool for tool in self.tools}
        # Define a new graph
        workflow = StateGraph(state_class)

        # Define the two nodes we will cycle between
        workflow.add_node("agent", self.call_model)
        workflow.add_node("tools", self.tool_node)

        # Set the entrypoint as `agent`
        # This means that this node is the first one called
        workflow.set_entry_point("agent")

        # We now add a conditional edge
        workflow.add_conditional_edges(
            # First, we define the start node. We use `agent`.
            # This means these are the edges taken after the `agent` node is called.
            "agent",
            # Next, we pass in the function that will determine which node is called next.
            self.should_continue,
            # Finally we pass in a mapping.
            # The keys are strings, and the values are other nodes.
            # END is a special node marking that the graph should finish.
            # What will happen is we will call `should_continue`, and then the output of that
            # will be matched against the keys in this mapping.
            # Based on which one it matches, that node will then be called.
            {
                # If `tools`, then we call the tool node.
                "continue": "tools",
                # Otherwise we finish.
                "end": END,
            },
        )

        # We now add a normal edge from `tools` to `agent`.
        # This means that after `tools` is called, `agent` node is called next.
        workflow.add_edge("tools", "agent")

        # Now we can compile and visualize our graph
        self.graph = workflow.compile()
    
    # Define our tool node
    def tool_node(self, state: type):
        outputs = []
        for tool_call in state[f"{self.name}_messages"][-1].tool_calls:
            tool_result = self.tools_by_name[tool_call["name"]].invoke(tool_call["args"])
            outputs.append(
                ToolMessage(
                    content=json.dumps(tool_result),
                    name=tool_call["name"],
                    tool_call_id=tool_call["id"],
                )
            )
        return {f"{self.name}_messages": outputs}


    # Define the node that calls the model
    def call_model(
        self,
        state: type,
        config: RunnableConfig,
    ):
        
        prompt = self.prompt
        response = self.model.invoke(prompt, config)
        # We return a list, because this will get added to the existing list
        return {f"{self.name}_messages": [response]}
    
    def should_continue(self, state: type):
        messages = state[f"{self.name}_messages"]
        last_message = messages[-1]
        # If there is no function call, then we finish
        if not last_message.tool_calls:
            return "end"
        # Otherwise if there is, we continue
        else:
            return "continue"

