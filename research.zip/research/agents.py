# from src.tools.vector_db import get_top_10_metrics
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import os
from langchain.tools import tool
from langgraph_swarm import create_swarm
from langgraph_swarm.handoff import _normalize_agent_name, METADATA_KEY_HANDOFF_DESTINATION
import random
from langchain_core.messages import AIMessage, BaseMessage, SystemMessage, ToolMessage
from typing import (
    Any,
    Callable,
    Literal,
    Optional,
    Sequence,
    Type,
    TypeVar,
    Union,
    cast,
    get_type_hints,
)
from langgraph.prebuilt.chat_agent_executor import add_messages

from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool, InjectedToolCallId, tool
from langgraph.prebuilt import InjectedState
from langgraph.types import Command, Send
from typing_extensions import Annotated
from langgraph.prebuilt.chat_agent_executor import AgentState


from langgraph_swarm import add_active_agent_router

from langchain_core.messages import AnyMessage
from langgraph.graph import StateGraph
from langgraph_swarm import SwarmState

load_dotenv()
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL")
LLM_MODEL = os.getenv("LLM_MODEL")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")


model = ChatOpenAI(model=LLM_MODEL, 
                       base_url=OPENAI_BASE_URL, 
                       openai_api_key=OPENAI_API_KEY, 
                       temperature=0)

prompts = {
    "manager": """
Hello, Agent!

Your primary task is to engage in a natural and informative conversation with the user to 
gather all necessary details for creating Prometheus alert rules based on their requirements. 
If at any moment the user asks technical questions about prometheus alerts, transfer it to the technical
agent that will answer all his questions. Transfer to a technician at the moment you are asked.
""",
    "technician": """
Hello, Agent!

Your primary task is to engage in a technical and informative conversation with the user about 
prometheus alert rules. If at any moment the user changes the conversation into something more general 
and non technical, transafer it to the manager agent that will take care of that type of conversations.

You have a tool to retrieve the top 10 metrics closest to the one that the user wants. If asked about metrics, use it

"""
}

def create_phandoff_tool(
    *, agent_name: str, name: str | None = None, description: str | None = None
) -> BaseTool:
    """Create a tool that can handoff control to the requested agent.

    Args:
        agent_name: The name of the agent to handoff control to, i.e.
            the name of the agent node in the multi-agent graph.
            Agent names should be simple, clear and unique, preferably in snake_case,
            although you are only limited to the names accepted by LangGraph
            nodes as well as the tool names accepted by LLM providers
            (the tool name will look like this: `transfer_to_<agent_name>`).
        name: Optional name of the tool to use for the handoff.
            If not provided, the tool name will be `transfer_to_<agent_name>`.
        description: Optional description for the handoff tool.
            If not provided, the tool description will be `Ask agent <agent_name> for help`.
    """
    if name is None:
        name = f"transfer_to_{_normalize_agent_name(agent_name)}"

    if description is None:
        description = f"Ask agent '{agent_name}' for help"

    @tool(name, description=description)
    def phandoff_to_agent(
        state: Annotated[dict, InjectedState],
        tool_call_id: Annotated[str, InjectedToolCallId],
    ):
        tool_message = ToolMessage(
            content=f"Successfully transferred to {agent_name}",
            name=name,
            tool_call_id=tool_call_id,
        )
        handoff_messages = state["messages"] + [tool_message]
        print("Agent name:", agent_name)
        return Command(
            #goto=agent_name,
            graph=Command.PARENT,
            goto=[Send(agent_name, {"custom_messages": handoff_messages, "active_agent": agent_name})],
        )

    phandoff_to_agent.metadata = {METADATA_KEY_HANDOFF_DESTINATION: agent_name}
    return phandoff_to_agent

class CustomState(AgentState):
    # we use this as a way of truck particular chat history using the other method in the readme
    active_agent: str

manager = create_react_agent(
    model=model,
    tools=[create_phandoff_tool(agent_name="technician_agent", description="Transfer to technician_agent to get the top 10 metrics.")],
    prompt=prompts["manager"],
    name="manager_agent",
    state_schema=CustomState
)  

technician = create_react_agent(
    model=model,
    tools=[#get_top_10_metrics, 
           create_phandoff_tool(agent_name="manager_agent", description="Transfer to manager_agent to get the top 10 metrics.")],
    prompt=prompts["technician"],
    name="technician_agent",
    state_schema=CustomState
)


def call_manager_agent(state):
    print("State manager agent:", state)
    response = manager.invoke({"messages": state["messages"]})
    if "active_agent" not in state:
        return {"messages": response["messages"]}
    # you can put any output transformation from agent state -> parent state
    return {"messages": response["messages"][-1:], "active_agent": state["active_agent"]}

def call_technician_agent(state):
    print("State technician agent:", state)
    response = technician.invoke({"messages": state["messages"]})
    # you can put any output transformation from agent state -> parent state
    return {"messages": response["messages"][-1:], "active_agent": state["active_agent"]}

workflow = (
    StateGraph(SwarmState)
    .add_node("manager_agent", call_manager_agent, destinations=("technician_agent",))
    .add_node("technician_agent", call_technician_agent, destinations=("manager_agent",))
)

workflow = add_active_agent_router(
    builder=workflow,
    route_to=["technician_agent", "manager_agent"],
    default_active_agent="manager_agent",
)

workflow = workflow.compile()

