from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv


from langgraph_swarm import add_active_agent_router

from langgraph.graph import StateGraph
from langgraph_swarm import SwarmState
from langgraph_swarm.handoff import create_handoff_tool
# from src.tools.vector_db import get_top_10_metrics
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import os
from langchain_core.messages import BaseMessage
from typing import (
    Sequence,
)
from langgraph.prebuilt.chat_agent_executor import add_messages
from langchain_core.tools import tool

from typing_extensions import Annotated
from langgraph.prebuilt.chat_agent_executor import AgentState
import pprint
from src.bot.research.react_agent import ReactAgent
from langgraph_swarm import add_active_agent_router


load_dotenv()
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL")
LLM_MODEL = os.getenv("LLM_MODEL")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

@tool
def add(a: int, b: int) -> int:
    """Add two numbers"""
    return a + b

class AliceState(AgentState):
    alice_messages: Annotated[Sequence[BaseMessage], add_messages]
    active_agent: str

class BobState(AgentState):
    bob_messages: Annotated[Sequence[BaseMessage], add_messages]
    active_agent: str

model = ChatOpenAI(model=LLM_MODEL, 
                   base_url=OPENAI_BASE_URL, 
                   openai_api_key=OPENAI_API_KEY, 
                   temperature=0)

alice = ReactAgent(
    model=model,
    tools=[add, create_handoff_tool(agent_name="bob")],
    prompt="You are Alice, an addition expert.",
    name="alice",
    state_class=AliceState,
).graph

bob = ReactAgent(
    model=model,
    tools=[create_handoff_tool(agent_name="alice", description="Transfer to Alice, she can help with math")],
    prompt="You are Bob, you speak like a pirate.",
    name="bob",
    state_class=BobState,
).graph

def call_alice(state: SwarmState):
    print("Calling Alice")
    pprint.pprint(state)
    print("Model input")
    print(state["messages"])
    response = alice.invoke({"alice_messages": state["messages"]})
    print("Alice response")
    pprint.pprint(response)
    return {**state, "messages": response["alice_messages"]}

def call_bob(state: SwarmState):
    print("Calling Bob")
    pprint.pprint(state)
    print("Model input")
    print(state["messages"])
    response = bob.invoke({"bob_messages": state["messages"]})
    print("Bob response")
    pprint.pprint(response)
    return {**state, "messages": response["bob_messages"]}

workflow = (
    StateGraph(SwarmState)
    .add_node("alice", call_alice, destinations=("bob",))
    .add_node("bob", call_bob, destinations=("alice",))
)

# this is the router that enables us to keep track of the last active agent
workflow = add_active_agent_router(
    builder=workflow,
    route_to=["alice", "bob"],
    default_active_agent="alice",
)

# compile the workflow
app = workflow.compile()

